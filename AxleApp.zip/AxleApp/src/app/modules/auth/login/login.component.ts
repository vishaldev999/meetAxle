import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  isLogin: boolean = false;
  isLoggingIn: boolean = false;
  returnUrl: string = '';

  constructor (private authService: AuthenticationService, private router: Router, private activatedRoute: ActivatedRoute) {
    
  }
  
  ngOnInit(): void {
    this.returnUrl = this.activatedRoute.snapshot.queryParams['returnUrl'] || '/';
    if (this.authService.isAuthenticated) {
      this.router.navigateByUrl(this.returnUrl)
    }
  }
}

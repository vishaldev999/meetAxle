import { Component } from '@angular/core';

@Component({
  selector: 'app-error-internal-server',
  templateUrl: './error-internal-server.component.html',
  styleUrls: ['./error-internal-server.component.scss']
})
export class ErrorInternalServerComponent {

}

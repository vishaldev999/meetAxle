import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ErrorInternalServerComponent } from './error-internal-server/error-internal-server.component';
import { ErrorNotFoundComponent } from './error-not-found/error-not-found.component';
import { ErrorUnauthorisedAccessComponent } from './error-unauthorised-access/error-unauthorised-access.component';



@NgModule({
  declarations: [
    ErrorInternalServerComponent,
    ErrorNotFoundComponent,
    ErrorUnauthorisedAccessComponent
  ],
  imports: [
    CommonModule
  ]
})
export class ErrorModule { }

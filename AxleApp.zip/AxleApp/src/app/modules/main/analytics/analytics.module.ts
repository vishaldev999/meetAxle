import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PracticeComponent } from './practice/practice.component';
import { ProviderComponent } from './provider/provider.component';
import { RegionComponent } from './region/region.component';
import { HygieneComponent } from './hygiene/hygiene.component';
import { AnalyticsRoutingModule } from './analytics-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
  declarations: [
    PracticeComponent,
    ProviderComponent,
    RegionComponent,
    HygieneComponent,
  ],
  imports: [
    AnalyticsRoutingModule,
    CommonModule,
    SharedModule
  ]
})
export class AnalyticsModule { }

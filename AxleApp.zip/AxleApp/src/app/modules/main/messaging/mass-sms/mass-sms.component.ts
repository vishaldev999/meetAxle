import { Component } from '@angular/core';

@Component({
  selector: 'app-mass-sms',
  templateUrl: './mass-sms.component.html',
  styleUrls: ['./mass-sms.component.scss']
})
export class MassSmsComponent {

}

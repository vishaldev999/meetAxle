import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InboxComponent } from './inbox/inbox.component';
import { MassSmsComponent } from './mass-sms/mass-sms.component';
import { MessagingRoutingModule } from './messaging-routing.module';



@NgModule({
  declarations: [
    InboxComponent,
    MassSmsComponent
  ],
  imports: [
    CommonModule,
    MessagingRoutingModule
  ]
})
export class MessagingModule { }

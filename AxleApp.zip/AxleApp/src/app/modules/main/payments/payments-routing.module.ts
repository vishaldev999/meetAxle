import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PendingComponent } from './pending/pending.component';
import { CompletedComponent } from './completed/completed.component';
import { RecurringComponent } from './recurring/recurring.component';
import { TransactionComponent } from './transaction/transaction.component';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'pending', component: PendingComponent },
  { path: 'completed', component: CompletedComponent },
  { path: 'recurring', component: RecurringComponent },
  { path: 'transaction', component: TransactionComponent },
  { path: '',  pathMatch:'full', redirectTo:'dashboard' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaymentsRoutingModule { }

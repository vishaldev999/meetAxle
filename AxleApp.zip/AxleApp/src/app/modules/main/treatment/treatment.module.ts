import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CallListComponent } from './call-list/call-list.component';
import { PendingComponent } from './pending/pending.component';
import { CompletedComponent } from './completed/completed.component';
import { TreatmentRoutingModule } from './treatment-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { OverviewComponent } from './dashboard/overview/overview.component';
import { StatsPracticeComponent } from './dashboard/stats-scheduled-practice/stats-practice.component';
import { UtsEmployeesComponent } from './dashboard/uts-outcomes-employees/uts-employees.component';
import { LoadingBlockComponent } from './dashboard/loading-block/loading-block.component';


@NgModule({
  declarations: [
    DashboardComponent,
    CallListComponent,
    PendingComponent,
    CompletedComponent,
    OverviewComponent,
    StatsPracticeComponent,
    UtsEmployeesComponent,
    LoadingBlockComponent,

  ],
  imports: [
    CommonModule,
    TreatmentRoutingModule,
    SharedModule,

  ]
})
export class TreatmentModule { }

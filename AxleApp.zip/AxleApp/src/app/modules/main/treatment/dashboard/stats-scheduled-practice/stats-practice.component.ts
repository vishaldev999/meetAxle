import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
@Component({
  selector: 'app-stats-practice',
  templateUrl: './stats-practice.component.html',
  styleUrls: ['./stats-practice.component.scss']
})
export class StatsPracticeComponent implements OnInit {
  practicestats: any[] = [];

  ngOnInit() {

    this.practicestats = [
      {
        practicename: 'Practice 1',
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        practicename: 'Practice 2',
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        practicename: 'Practice 3',
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        practicename: 'Practice 4',
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        practicename: 'Practice 5',
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      },
      {
        practicename: 'Practice 6',
        schdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        unschdlepro: {
          amount: '$185,785.23',
          procedures: '458 procedures'
        },
        convrate: {
          amount: '$185,785.23',
          plans: '458 procedures'
        }
      }
    ];

  }

  // Highcharts 

  Highcharts: typeof Highcharts = Highcharts;
  chartOptions: Highcharts.Options = {
    xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      crosshair: {
        //width: 100,
        color: '#0acbdc1a'
      },
      labels: {
        style: {
          fill: '#363F57',
          color: '#363F57',
          fontWeight: '400',
          fontSize: '12px',
        }
      },
      lineWidth: 1,
      lineColor: 'transparent',
    },
    yAxis: {
      labels: {
        format: '${text}M', // The $ is literally a dollar unit
        style: {
          fill: '#363F57',
          color: '#363F57',
          fontWeight: '400',
          fontSize: '12px',
        }
      },
      title: { text: '' },
    },
    title: { text: '' },
    credits: { enabled: false },
    series: [{
      showInLegend: false,
      name: 'Households',
      data: [2.1, 1.8, 1.8, 2.8, 2.1, 2.1, 3.5, 4, 3.4, 3.4, 4.2, 2.1],
      type: 'column',
      color: '#0ACADC',
      borderWidth: 0,
      borderRadius: 0, pointPadding: 0.07,
    }],
    tooltip: {
      shared: true,
      outside: true,
      useHTML: true,
      backgroundColor: '#fff',
      borderRadius: 10,
      positioner: function (labelWidth, _, point) {
        //console.log(labelWidth, _, point)
        return {
          x: point.plotX - 20,
          y: point.plotY - 120,
        };
      },
      formatter: function (response) {
        //console.log(response);
        let tooltip = '<div class="chart_tooltip Jan">';
        tooltip += '<h4>Jan 2023</h4>';
        tooltip += '<div class = "tooltip-content">';
        tooltip += '<div class="item gross"><p><b></b><span>Gross Production</span></p><h6>$0</h6></div>';
        // tooltip += '<div class="item adjusted"><p><b></b><span>Adjusted Production</span></p><h6>$0</h6></div>';
        // tooltip += '<div class="item total"><p><b></b><span>Total Adjustments</span></p><h6>$0</h6></div>';
        // tooltip += '<div class="item scheduled"><p><b></b><span>Scheduled Production</span></p><h6>$0</h6></div>';
        tooltip += '</div>';
        tooltip += '</div>'
        return tooltip;
      }
    }

  }
}

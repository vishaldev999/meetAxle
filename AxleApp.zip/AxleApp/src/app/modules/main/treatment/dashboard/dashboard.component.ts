import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {


  isTableData = false;
  isVisible = true;

  ngOnInit() {
    setTimeout(() => {
      this.isTableData = true;
      this.isVisible = false;

    }, 2000); // 2000 milliseconds = 2 seconds
  }


}

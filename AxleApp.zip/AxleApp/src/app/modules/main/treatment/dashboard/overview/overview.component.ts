import { Component } from '@angular/core';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss']
})
export class OverviewComponent {
  tooltipValue: string = "";
  isShowDivIf = false;

  removeDisplayDivIf() {
    this.tooltipValue = '';
  }

  toggleDisplayDivIf(tootipitem: string) {
    if (this.tooltipValue == tootipitem)
      this.tooltipValue = "";
    else
      this.tooltipValue = tootipitem;
  }
}

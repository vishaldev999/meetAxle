import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UsersComponent } from './users/users.component';
import { PracticesComponent } from './practices/practices.component';
import { EligibilityComponent } from './eligibility/eligibility.component';
import { EngagementComponent } from './engagement/engagement.component';
import { FormsComponent } from './forms/forms.component';
import { GoalsComponent } from './goals/goals.component';
import { MessagingComponent } from './messaging/messaging.component';
import { PayementsComponent } from './payements/payements.component';
import { ReviewsComponent } from './reviews/reviews.component';
import { ScheduleComponent } from '../schedule/schedule/schedule.component';
import { TreatmentComponent } from './treatment/treatment.component';

const routes: Routes = [
  { path: 'users', component: UsersComponent },
  { path: 'practices', component: PracticesComponent },
  { path: 'eligibility', component: EligibilityComponent },
  { path: 'engagement', component: EngagementComponent },
  { path: 'forms', component: FormsComponent },
  { path: 'goals', component: GoalsComponent },
  { path: 'messaging', component: MessagingComponent },
  { path: 'payements', component: PayementsComponent },
  { path: 'reviews', component: ReviewsComponent },
  { path: 'schedule', component: ScheduleComponent },
  { path: 'treatment', component: TreatmentComponent },
  { path: '',  pathMatch:'full', redirectTo:'users' }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SettingsRoutingModule { }

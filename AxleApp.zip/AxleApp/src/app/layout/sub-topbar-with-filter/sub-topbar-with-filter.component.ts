import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-topbar-with-filter',
  templateUrl: './sub-topbar-with-filter.component.html',
  styleUrls: ['./sub-topbar-with-filter.component.scss']
})
export class SubTopbarWithFilterComponent implements OnInit {
  users: any[] = [];
  selectedUsers!: any;
  filteredUsers: any = [];

  cities: any[] = [];
  selectedCities: any[] = [];

  addUsrSlctdPrtcs:any= null;
  addUsrPrtcsList = [
    {
      practiceName: 'Brooks-Ortho',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Brooks-Pedo',
      practiceAddress: '2302 SE Military Dr. Suite 101,San Antonio,Texas,78233'
    },
    {
      practiceName: 'Cibolo-Ortho',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Cibolo-Pedo',
      practiceAddress: '3738 Cibolo Valley Drive,Cibolo,TX,78108'
    },
    {
      practiceName: 'Culebra-Ortho',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    },
    {
      practiceName: 'Culebra-Pedo',
      practiceAddress: '8839 Culebra Rd., Ste. 108,San Antonio,TX,78251'
    }
  ];

  //Popup Fields
  userFullname: string = '';
  userEmailAddress: string = '';
  userMobilePhone: string = '';

  filterUsers(event:any) {
    let filtered: any[] = [];
        let query = event.query;
        console.log(event)
        filtered = this.users.filter((e:any)=>{ return e.name.toLowerCase().indexOf(query.toLowerCase())!=-1});
        console.log(filtered)
        this.filteredUsers = filtered;
  }

  ngOnInit() {
    this.users = [
      {
       name:'Ashish Kaushik'
     },
     {
       name:'Nisar'
     },
     {
       name:'Rachel Etherington'
     },
     {
       name:'Anurag'
     },
     {
       name:'Abhishek'
     }
   ];

    this.cities = [
      { name: 'New York', code: 'NY' },
      { name: 'Rome', code: 'RM' },
      { name: 'London', code: 'LDN' },
      { name: 'Istanbul', code: 'IST' },
      { name: 'Paris', code: 'PRS' }
    ];
  }
}

import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CurrentMenuService {

  private currentparent: BehaviorSubject<string> = new BehaviorSubject<string>('');
  private currentmenu: BehaviorSubject<string> = new BehaviorSubject<string>('');
  constructor() { }

  setParent(menuid: string) {
    this.currentparent.next(menuid);
  }

  public get getParentMenu() {
    return this.currentparent;
  }
  public get getMenu() {
    return this.currentmenu
  }
  
  setMenu(menuid: string) {
    this.currentmenu.next(menuid);
  }
}

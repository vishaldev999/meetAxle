import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject, catchError, map, of, tap } from 'rxjs';
import { Permission } from '../modals/identity/permission';
import { JwtHelperService } from '@auth0/angular-jwt';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { LocalStorageService } from './local-storage.service';
import { Token } from '../modals/identity/token';
import { Result } from '../modals/wrapper/Result';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  private baseUrl = "";
  private currentUserTokenSource = new BehaviorSubject<string | null>(this.getStorageToken);
  public currentUserToken$ = this.currentUserTokenSource.asObservable();

  private permissions$ = new Subject<Permission[]>();
  private permissions: Permission[] = [];

  private tempTokenResponse!: Token | null;

  constructor(private http: HttpClient, private localStorage: LocalStorageService, private router: Router) {

  }

  public get getToken(): string | null {
    return this.currentUserTokenSource?.getValue();
  }

  public get getStorageToken(): string | null {
    return localStorage.getItem('token') ?? null;
  }

  public get getFullName(): string {
    const decodedToken = this.getDecodedToken();
    return decodedToken?.fullName ?? '';
  }

  public get getUserId(): string {
    const decodedToken = this.getDecodedToken();
    return !!(decodedToken) ? decodedToken['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'] : '';
  }

  public get getUserClaims() {
    let claims: any[] = [];
    return claims;
  }

  public get getEmail(): string {
    const decodedToken = this.getDecodedToken();
    return !!(decodedToken) ? decodedToken['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress'] : '';
  }

  private get getStorageRefreshToken(): string | null {
    return this.localStorage.getItem('refreshToken');
  }

  public get isAuthenticated(): boolean {
    const token = localStorage.getItem('token');
    if (!!(token)) {
      const jwtService = new JwtHelperService();
      return !jwtService.isTokenExpired(token);
    }
    return false;
  }

  public async isAuthorized(authorizationType: string, allowedData: string[]) {
    if (allowedData == null || allowedData.length === 0) {
      return true;
    }
    const decodeToken = this.getDecodedToken();
    if (!decodeToken) {
      this.setStorageToken(null);
      this.router.navigateByUrl('/auth/login');
      return false;
    }

    if (authorizationType === 'Role') {
      const roles = decodeToken['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
      if (roles === undefined || roles.length === 0) return false;
      return allowedData.some(a => roles.includes(a));

    } else if (authorizationType === 'Permission') {
      if (this.permissions === undefined || this.permissions.length === 0) return false;
      let permissionClaims = this.permissions.map(function (a) { return a.permission; });
      return allowedData.some(r => permissionClaims.includes(r));
    }
    return false;
  }

  public loadCurrentUser(): Observable<string | null> {
    const token = this.getStorageToken;
    const currentUserToken = !!(token) ? token : null;
    this.setToken(currentUserToken);
    return of(currentUserToken);
  }

  public login(values: { email: string, password: string, tenant: string }): Observable<Token> {
    const headerDict = {
      'tenant': values.tenant
    }
    const requestOptions = {
      headers: new HttpHeaders(headerDict),
    };
    return this.http.post<Token>(this.baseUrl + 'tokens', values, requestOptions)
      .pipe(
        tap((result: Token) => {
          this.setStorageToken(result);
        }),
        map((result: Token) => result ?? undefined)
      );
  }

  public logout(): void {
    this.setStorageToken(null);
    this.router.navigateByUrl('/auth/login');
  }

  public tryRefreshingToken(): void {
    const jwtToken = this.getStorageToken ?? '';
    const refreshToken = this.getStorageRefreshToken ?? '';

    this.http.post<Result<Token>>(this.baseUrl + 'identity/tokens/refresh', {
      'refreshToken': refreshToken,
      'token': jwtToken
    })
      .pipe(
        tap((result: Result<Token>) => {
          if (result.succeeded) {
            this.setStorageToken(result.data);
          } else {
            this.logout();
          }
        }),
        catchError((error) => {
          console.error(error);
          this.logout();
          return of(null);
        }))
      .subscribe();
  }

  getPermissions(id: string): Promise<Result<Permission[]> | undefined> {
    return this.http.get<Result<Permission[]>>(this.baseUrl + `${id}/permissions`).toPromise();
  }

  private async setPermission() {
    var response = await this.getPermissions(this.getUserId);
    if (response?.succeeded) {
      this.permissions = response.data;
      this.permissions$.next(this.permissions);
    }
  }

  private setToken(token: string | null) {
    this.currentUserTokenSource.next(token);
    // this.setPermission();

  }

  private setStorageToken(data: Token | null) {
    if (data != null && data?.token?.length > 0) {
      this.localStorage.setItem('token', data.token);
      this.localStorage.setItem('refreshToken', data.refreshToken);
      this.setToken(data.token);
    } else {
      this.localStorage.removeItem('token');
      this.localStorage.removeItem('refreshToken');
      this.setToken(null);
    }
  }

  private getDecodedToken() {
    let token = this.getStorageToken;
    if (!(token)) {
      return null;
    }
    const jwtService = new JwtHelperService();
    const decodedToken = jwtService.decodeToken(token);
    return decodedToken;
  }
}

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../services/authentication.service';
import { MessageService } from 'primeng/api';

@Injectable({ providedIn: "root" })
export class PermissionGuard implements CanActivate {
  constructor(
    private authService: AuthenticationService,
    private messageService: MessageService,
    private router: Router
  ) { }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    const allowedPermissions = route.data['allowedPermissions'];
    const isAuthorized = this.authService.isAuthorized('Permission', allowedPermissions);
    if (!isAuthorized) { 
      this.messageService.add({ severity: 'error', summary: `You are not authoroized to access the resource` });
      this.router.navigateByUrl('access-denied');
    }
    return true;
    // return isAuthorized;
  }

}

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfileComponent } from './components/profile/profile.component';
import { HasPermissionDirective } from './directives/has-permission.directive';
import { GetInitialsPipe } from './pipes/get-initials.pipe';
import { PrimeNgModules } from './primeng.module';
import { VirtualTerminalComponent } from './components/virtual-terminal/virtual-terminal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SafeHtmlPipe } from './pipes/safe-html.pipe';



@NgModule({
  declarations: [
    ProfileComponent,
    HasPermissionDirective,
    GetInitialsPipe,
    VirtualTerminalComponent,
    SafeHtmlPipe
  ],
  imports: [
    CommonModule,
    PrimeNgModules,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    PrimeNgModules,
    VirtualTerminalComponent,
    FormsModule,
    ReactiveFormsModule,
    SafeHtmlPipe,
    GetInitialsPipe
  ]
})
export class SharedModule {}
